document.addEventListener('DOMContentLoaded', async function() {
  const loginForm = document.getElementById('login-form');
  const loginButton = document.getElementById('login-button');
  const loginStatus = document.getElementById('login-status');
  const conversationList = document.getElementById('conversation-list');
  const conversationsUl = document.getElementById('conversations');
  const saveButton = document.getElementById('save-button');

  // Check if user is already logged in
  const storage = await browser.storage.sync.get(['nextcloudUrl', 'loginName', 'appPassword']);
  if (storage.nextcloudUrl && storage.loginName && storage.appPassword) {
    loginForm.style.display = 'none';
    await loadConversations();
  }

  loginButton.addEventListener('click', async function() {
    const nextcloudUrl = document.getElementById('nextcloud-url').value;
    if (!nextcloudUrl) {
      alert('Please enter your Nextcloud URL');
      return;
    }

    loginForm.style.display = 'none';
    loginStatus.style.display = 'block';

    try {
      // Initiate Login Flow v2
      const response = await fetch(`${nextcloudUrl}/index.php/login/v2`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      const data = await response.json();

      // Open the login URL in a new tab
      browser.tabs.create({ url: data.login });

      // Start polling for the token
      pollForToken(nextcloudUrl, data.poll.endpoint, data.poll.token);
    } catch (error) {
      console.error('Error initiating login:', error);
      loginForm.style.display = 'block';
      loginStatus.style.display = 'none';
    }
  });

  async function pollForToken(nextcloudUrl, pollEndpoint, pollToken) {
    try {
      const response = await fetch(pollEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `token=${encodeURIComponent(pollToken)}`
      });
      const data = await response.json();

      if (data.server && data.loginName && data.appPassword) {
        // Login successful, save the credentials
        await browser.storage.sync.set({
          nextcloudUrl: nextcloudUrl,
          loginName: data.loginName,
          appPassword: data.appPassword
        });

        loginStatus.style.display = 'none';
        await loadConversations();
      } else {
        // Continue polling
        setTimeout(() => pollForToken(nextcloudUrl, pollEndpoint, pollToken), 3000);
      }
    } catch (error) {
      console.error('Error polling for token:', error);
      loginForm.style.display = 'block';
      loginStatus.style.display = 'none';
    }
  }

  async function loadConversations() {
    try {
      const response = await browser.runtime.sendMessage({action: "getConversations"});
      if (response && response.length > 0) {
        conversationsUl.innerHTML = '';
        response.forEach(conversation => {
          const li = document.createElement('li');
          const checkbox = document.createElement('input');
          checkbox.type = 'checkbox';
          checkbox.value = conversation.token;
          checkbox.id = `conversation-${conversation.token}`;
          const label = document.createElement('label');
          label.htmlFor = `conversation-${conversation.token}`;
          label.textContent = conversation.displayName;
          li.appendChild(checkbox);
          li.appendChild(label);
          conversationsUl.appendChild(li);
        });
        conversationList.style.display = 'block';
      } else {
        console.error('No conversations returned');
        // Handle the case where no conversations are returned
        conversationList.innerHTML = '<p>No conversations found. Please check your Nextcloud Talk app.</p>';
        conversationList.style.display = 'block';
      }
    } catch (error) {
      console.error('Error loading conversations:', error);
      // Handle the error case
      conversationList.innerHTML = '<p>Error loading conversations. Please try logging in again.</p>';
      conversationList.style.display = 'block';
    }
  }

  saveButton.addEventListener('click', async function() {
    const selectedConversations = Array.from(conversationsUl.querySelectorAll('input:checked'))
      .map(checkbox => checkbox.value);
    try {
      await browser.storage.sync.set({selectedConversations: selectedConversations});
      console.log('Conversations saved');
    } catch (error) {
      console.error('Error saving conversations:', error);
    }
  });
});