// content-script.js
// This file is currently empty, but if I need to add content in the future, 
// make sure to use the `browser` namespace instead of `chrome`, don't be a dummy.